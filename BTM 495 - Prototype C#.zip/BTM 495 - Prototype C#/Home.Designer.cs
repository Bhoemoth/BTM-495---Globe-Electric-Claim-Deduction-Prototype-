﻿namespace btm_495
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Create_claim_btn = new System.Windows.Forms.Button();
            this.validate_claim_btn = new System.Windows.Forms.Button();
            this.dispute_claim_btn = new System.Windows.Forms.Button();
            this.welcome_label = new System.Windows.Forms.Label();
            this.exit_btn = new System.Windows.Forms.Button();
            this.Endbtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Create_claim_btn
            // 
            this.Create_claim_btn.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Create_claim_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Create_claim_btn.Location = new System.Drawing.Point(38, 182);
            this.Create_claim_btn.Name = "Create_claim_btn";
            this.Create_claim_btn.Size = new System.Drawing.Size(179, 48);
            this.Create_claim_btn.TabIndex = 0;
            this.Create_claim_btn.Text = "Create Claim";
            this.Create_claim_btn.UseVisualStyleBackColor = true;
            this.Create_claim_btn.Click += new System.EventHandler(this.Create_claim_btn_Click);
            // 
            // validate_claim_btn
            // 
            this.validate_claim_btn.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.validate_claim_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.validate_claim_btn.Location = new System.Drawing.Point(251, 182);
            this.validate_claim_btn.Name = "validate_claim_btn";
            this.validate_claim_btn.Size = new System.Drawing.Size(179, 48);
            this.validate_claim_btn.TabIndex = 1;
            this.validate_claim_btn.Text = "Validate Claim";
            this.validate_claim_btn.UseVisualStyleBackColor = true;
            this.validate_claim_btn.Click += new System.EventHandler(this.validate_claim_btn_Click);
            // 
            // dispute_claim_btn
            // 
            this.dispute_claim_btn.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.dispute_claim_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dispute_claim_btn.Location = new System.Drawing.Point(38, 251);
            this.dispute_claim_btn.Name = "dispute_claim_btn";
            this.dispute_claim_btn.Size = new System.Drawing.Size(179, 48);
            this.dispute_claim_btn.TabIndex = 2;
            this.dispute_claim_btn.Text = "Dispute Claim";
            this.dispute_claim_btn.UseVisualStyleBackColor = true;
            this.dispute_claim_btn.Click += new System.EventHandler(this.dispute_claim_btn_Click);
            // 
            // welcome_label
            // 
            this.welcome_label.AutoSize = true;
            this.welcome_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.welcome_label.Location = new System.Drawing.Point(81, 53);
            this.welcome_label.Name = "welcome_label";
            this.welcome_label.Size = new System.Drawing.Size(304, 69);
            this.welcome_label.TabIndex = 3;
            this.welcome_label.Text = "Welcome!";
            this.welcome_label.Click += new System.EventHandler(this.label1_Click);
            // 
            // exit_btn
            // 
            this.exit_btn.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.exit_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit_btn.Location = new System.Drawing.Point(136, 322);
            this.exit_btn.Name = "exit_btn";
            this.exit_btn.Size = new System.Drawing.Size(179, 48);
            this.exit_btn.TabIndex = 4;
            this.exit_btn.Text = "Exit";
            this.exit_btn.UseVisualStyleBackColor = true;
            this.exit_btn.Click += new System.EventHandler(this.exit_btn_Click);
            // 
            // Endbtn
            // 
            this.Endbtn.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Endbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Endbtn.Location = new System.Drawing.Point(251, 251);
            this.Endbtn.Name = "Endbtn";
            this.Endbtn.Size = new System.Drawing.Size(179, 48);
            this.Endbtn.TabIndex = 2;
            this.Endbtn.Text = "End Claim";
            this.Endbtn.UseVisualStyleBackColor = true;
            this.Endbtn.Click += new System.EventHandler(this.Endbtn_Click);
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(473, 391);
            this.Controls.Add(this.exit_btn);
            this.Controls.Add(this.welcome_label);
            this.Controls.Add(this.Endbtn);
            this.Controls.Add(this.dispute_claim_btn);
            this.Controls.Add(this.validate_claim_btn);
            this.Controls.Add(this.Create_claim_btn);
            this.Name = "Home";
            this.Text = "Home";
            this.Load += new System.EventHandler(this.Home_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Create_claim_btn;
        private System.Windows.Forms.Button validate_claim_btn;
        private System.Windows.Forms.Button dispute_claim_btn;
        private System.Windows.Forms.Label welcome_label;
        private System.Windows.Forms.Button exit_btn;
        private System.Windows.Forms.Button Endbtn;
    }
}

