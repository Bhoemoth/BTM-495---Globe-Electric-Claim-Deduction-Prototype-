﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace btm_495
{
    public partial class Dispute_Claim : Form

    {
        MySqlConnection dbConn = new MySqlConnection("server = 127.0.0.1; user id = root; password= SQL123; database=btm 495");
        int Contactid = 0;
        public Dispute_Claim()
        {
            InitializeComponent();
        }

        private void exit_btn_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            this.Hide();
            home.ShowDialog();
            this.Close();
        }

        private void Dispute_Claim_Load(object sender, EventArgs e)
        {
           
            load_data();
        }

        private void dispute_btn_Click(object sender, EventArgs e)
        {
            if (Discodetxt.Text != "##########" && Disputebox.Text != "Please add a note here.")
            {
                dbConn.Open();
                MySqlDataAdapter SDA = new MySqlDataAdapter("UPDATE Claim SET Claim_Status = 'Disputed' WHERE Claim_ID ='" + Discodetxt.Text + "'", dbConn);
                DataTable DATA = new DataTable();
                SDA.SelectCommand.ExecuteNonQuery();
                dbConn.Close();

              

                MySqlCommand cmd = new MySqlCommand("UPDATE Claim SET Claim_Notes = '" + Disputebox.Text + "' WHERE Claim_ID ='" + Discodetxt.Text + "'", dbConn);
                dbConn.Open();
                cmd.ExecuteNonQuery();
                dbConn.Close();

                load_data();

                MessageBox.Show("The customer has been sent the imformation about the claim dispute via email.");
                Discodetxt.Text = "##########";
                Disputebox.Text = "Please add a note here.";
                Discodetxt.ForeColor = Color.DarkGray;
                Disputebox.ForeColor = Color.DarkGray;
               
            }
                 else
            {
                MessageBox.Show("Error!" + "\n" + "Either the data entered is invalid or required data fields have been left empty");
                Discodetxt.Text = "##########";
                Discodetxt.ForeColor = Color.DarkGray;
                Disputebox.Text = "Please add a note here.";
                Disputebox.ForeColor = Color.DarkGray;
            }

            }

        //load data
        public void load_data()
            {
            dbConn.Open();
            MySqlDataAdapter SDA = new MySqlDataAdapter("Select Claim_ID,Concat('$',Format(Claim_Amount, 'c')) As Claim_Amount, Claim_Status, Claim_Deduction_Code, Claim_Date, Order_ID, Claim_Description, Claim_Notes from claim", dbConn);
            DataTable DATA = new DataTable();
            SDA.Fill(DATA);
            DisputeGview.DataSource = DATA;
            dbConn.Close();

            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (Discodetxt.Text != "##########" && Disputebox.Text != "Please add a note here.")
            {
                dbConn.Open();
            MySqlDataAdapter SDA = new MySqlDataAdapter("UPDATE Claim SET Claim_Status = 'Denied' WHERE Claim_ID ='" + Discodetxt.Text + "'", dbConn);
            DataTable DATA = new DataTable();
            SDA.SelectCommand.ExecuteNonQuery();
            dbConn.Close();

            MySqlCommand cmd = new MySqlCommand("UPDATE Claim SET Claim_Notes = '" + Disputebox.Text + "' WHERE Claim_ID ='" + Discodetxt.Text + "'", dbConn);
            dbConn.Open();
            cmd.ExecuteNonQuery();
            dbConn.Close();

                load_data();

            MessageBox.Show("The customer accepted the information about claim dispute so the claim has been denied.");
                Discodetxt.Text = "##########";
                Discodetxt.ForeColor = Color.DarkGray;
                Disputebox.Text = "Please add a note here.";
                Disputebox.ForeColor = Color.DarkGray;
            }
            else
            {
                MessageBox.Show("Error!" + "\n" + "Either the data entered is invalid or required data fields have been left empty");
                Discodetxt.Text = "##########";
                Discodetxt.ForeColor = Color.DarkGray;
                Disputebox.Text = "Please add a note here.";
                Disputebox.ForeColor = Color.DarkGray;
            }


        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Discodetxt.Text != "##########" && Disputebox.Text != "Please add a note here.")
            {

                dbConn.Open();
            MySqlDataAdapter SDA = new MySqlDataAdapter("UPDATE Claim SET Claim_Status = 'Disputed' WHERE Claim_ID ='" + Discodetxt.Text + "'", dbConn);
            DataTable DATA = new DataTable();
            SDA.SelectCommand.ExecuteNonQuery();
            dbConn.Close();

            MySqlCommand cmd = new MySqlCommand("UPDATE Claim SET Claim_Notes = '" + Disputebox.Text + "' WHERE Claim_ID ='" + Discodetxt.Text + "'", dbConn);
            dbConn.Open();
            cmd.ExecuteNonQuery();
            dbConn.Close();

                load_data();

            MessageBox.Show("The customer denied the information about claim dispute." + "\n" + "Additional evidence regarding the claim should be sent to the customer via email.");
                Discodetxt.Text = "##########";
                Discodetxt.ForeColor = Color.DarkGray;
                Disputebox.Text = "Please add a note here.";
                Disputebox.ForeColor = Color.DarkGray;
            }
                 else
            {
                MessageBox.Show("Error!" + "\n" + "Either the data entered is invalid or required data fields have been left empty");
                Discodetxt.Text = "##########";
                Discodetxt.ForeColor = Color.DarkGray;
                Disputebox.Text = "Please add a note here.";
                Disputebox.ForeColor = Color.DarkGray;
            }
}

        private void DisputeGview_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (DisputeGview.CurrentRow.Index != -1)

            {
                Contactid = Convert.ToInt32(DisputeGview.CurrentRow.Cells[0].Value.ToString());
                Discodetxt.Text = DisputeGview.CurrentRow.Cells[0].Value.ToString();
                Discodetxt.ForeColor = Color.Black;
            }
        }

        private void Discodetxt_Enter(object sender, EventArgs e)
        {
            if (Discodetxt.Text == "##########")
            {
                Discodetxt.Text = "";

                Discodetxt.ForeColor = Color.Black;
            }
        }

        private void Discodetxt_Leave(object sender, EventArgs e)
        {
            if (Discodetxt.Text == "")
            {
                Discodetxt.Text = "##########";

                Discodetxt.ForeColor = Color.DarkGray;
            }
        }

        private void dispute_clm_lbl_Click(object sender, EventArgs e)
        {

        }

        private void Disputebox_Enter(object sender, EventArgs e)
        {
            if (Disputebox.Text == "Please add a note here.")
            {
                Disputebox.Text = "";

                Disputebox.ForeColor = Color.Black;
            }
    }

        private void Disputebox_Leave(object sender, EventArgs e)
        {
            if (Disputebox.Text == "")
            {
                Disputebox.Text = "Please add a note here.";
                Disputebox.ForeColor = Color.DarkGray;
            } 
        }
    }
}
