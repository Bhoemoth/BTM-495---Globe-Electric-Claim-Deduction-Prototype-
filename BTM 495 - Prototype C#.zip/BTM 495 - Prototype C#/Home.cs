﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace btm_495
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Create_claim_btn_Click(object sender, EventArgs e)
        {
            Create_Claim create_Claim = new Create_Claim();
            this.Hide();
            create_Claim.ShowDialog();
            this.Close();
          
               
        }

        private void validate_claim_btn_Click(object sender, EventArgs e)
        {
            Validate_Claim validate_Claim = new Validate_Claim();
            this.Hide();
            validate_Claim.ShowDialog();
            this.Close();

        }

        private void dispute_claim_btn_Click(object sender, EventArgs e)
        {
            Dispute_Claim dispute_Claim = new Dispute_Claim();
            this.Hide();
            dispute_Claim.ShowDialog();
            this.Close();

        }

        private void exit_btn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Home_Load(object sender, EventArgs e)
        {

        }

        private void Endbtn_Click(object sender, EventArgs e)
        {
            End_Claim End_Claim = new End_Claim();
            this.Hide();
            End_Claim.ShowDialog();
            this.Close();
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }
    }
}

// Update and delete
// exception handling
//way to fix what happens when a code that is not translated happens
// REARANGE CREATE CLAIM COLUMN - put description at the end
// Change claim descritoion column data type in Sql
