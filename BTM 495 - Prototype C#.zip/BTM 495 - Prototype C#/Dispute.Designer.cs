﻿namespace btm_495
{
    partial class Dispute_Claim
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exit_btn = new System.Windows.Forms.Button();
            this.dispute_btn = new System.Windows.Forms.Button();
            this.dispute_clm_lbl = new System.Windows.Forms.Label();
            this.code_lbl = new System.Windows.Forms.Label();
            this.Discodetxt = new System.Windows.Forms.TextBox();
            this.DisputeGview = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.Disputebox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.DisputeGview)).BeginInit();
            this.SuspendLayout();
            // 
            // exit_btn
            // 
            this.exit_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit_btn.Location = new System.Drawing.Point(1176, 389);
            this.exit_btn.Name = "exit_btn";
            this.exit_btn.Size = new System.Drawing.Size(186, 43);
            this.exit_btn.TabIndex = 10;
            this.exit_btn.Text = "Back";
            this.exit_btn.UseVisualStyleBackColor = true;
            this.exit_btn.Click += new System.EventHandler(this.exit_btn_Click);
            // 
            // dispute_btn
            // 
            this.dispute_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dispute_btn.Location = new System.Drawing.Point(22, 389);
            this.dispute_btn.Name = "dispute_btn";
            this.dispute_btn.Size = new System.Drawing.Size(186, 43);
            this.dispute_btn.TabIndex = 9;
            this.dispute_btn.Text = "Dispute Claim";
            this.dispute_btn.UseVisualStyleBackColor = true;
            this.dispute_btn.Click += new System.EventHandler(this.dispute_btn_Click);
            // 
            // dispute_clm_lbl
            // 
            this.dispute_clm_lbl.AutoSize = true;
            this.dispute_clm_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dispute_clm_lbl.Location = new System.Drawing.Point(89, 26);
            this.dispute_clm_lbl.Name = "dispute_clm_lbl";
            this.dispute_clm_lbl.Size = new System.Drawing.Size(304, 51);
            this.dispute_clm_lbl.TabIndex = 7;
            this.dispute_clm_lbl.Text = "Dispute Claim";
            this.dispute_clm_lbl.Click += new System.EventHandler(this.dispute_clm_lbl_Click);
            // 
            // code_lbl
            // 
            this.code_lbl.AutoSize = true;
            this.code_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.code_lbl.Location = new System.Drawing.Point(93, 133);
            this.code_lbl.Name = "code_lbl";
            this.code_lbl.Size = new System.Drawing.Size(94, 25);
            this.code_lbl.TabIndex = 13;
            this.code_lbl.Text = "Claim ID";
            // 
            // Discodetxt
            // 
            this.Discodetxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Discodetxt.ForeColor = System.Drawing.Color.DarkGray;
            this.Discodetxt.Location = new System.Drawing.Point(251, 133);
            this.Discodetxt.Name = "Discodetxt";
            this.Discodetxt.Size = new System.Drawing.Size(127, 27);
            this.Discodetxt.TabIndex = 14;
            this.Discodetxt.Text = "##########";
            this.Discodetxt.Enter += new System.EventHandler(this.Discodetxt_Enter);
            this.Discodetxt.Leave += new System.EventHandler(this.Discodetxt_Leave);
            // 
            // DisputeGview
            // 
            this.DisputeGview.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.DisputeGview.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.DisputeGview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DisputeGview.Location = new System.Drawing.Point(496, 37);
            this.DisputeGview.Name = "DisputeGview";
            this.DisputeGview.RowHeadersWidth = 51;
            this.DisputeGview.RowTemplate.Height = 24;
            this.DisputeGview.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DisputeGview.Size = new System.Drawing.Size(866, 334);
            this.DisputeGview.TabIndex = 15;
            this.DisputeGview.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DisputeGview_CellClick);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(483, 389);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(186, 43);
            this.button1.TabIndex = 9;
            this.button1.Text = "Send Evidence";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(251, 389);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(186, 43);
            this.button2.TabIndex = 9;
            this.button2.Text = "Deny Claim";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Disputebox
            // 
            this.Disputebox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Disputebox.ForeColor = System.Drawing.Color.DarkGray;
            this.Disputebox.Location = new System.Drawing.Point(36, 182);
            this.Disputebox.Multiline = true;
            this.Disputebox.Name = "Disputebox";
            this.Disputebox.Size = new System.Drawing.Size(397, 177);
            this.Disputebox.TabIndex = 16;
            this.Disputebox.Text = "Please add a note here.";
            this.Disputebox.Enter += new System.EventHandler(this.Disputebox_Enter);
            this.Disputebox.Leave += new System.EventHandler(this.Disputebox_Leave);
            // 
            // Dispute_Claim
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1382, 447);
            this.Controls.Add(this.Disputebox);
            this.Controls.Add(this.DisputeGview);
            this.Controls.Add(this.Discodetxt);
            this.Controls.Add(this.code_lbl);
            this.Controls.Add(this.exit_btn);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dispute_btn);
            this.Controls.Add(this.dispute_clm_lbl);
            this.Name = "Dispute_Claim";
            this.Text = "Dispute";
            this.Load += new System.EventHandler(this.Dispute_Claim_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DisputeGview)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button exit_btn;
        private System.Windows.Forms.Button dispute_btn;
        private System.Windows.Forms.Label dispute_clm_lbl;
        private System.Windows.Forms.Label code_lbl;
        private System.Windows.Forms.TextBox Discodetxt;
        private System.Windows.Forms.DataGridView DisputeGview;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox Disputebox;
    }
}