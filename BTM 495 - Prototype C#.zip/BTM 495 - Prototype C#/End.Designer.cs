﻿namespace btm_495
{
    partial class End_Claim
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.EndGview = new System.Windows.Forms.DataGridView();
            this.Endtxt = new System.Windows.Forms.TextBox();
            this.code_lbl = new System.Windows.Forms.Label();
            this.End_clm_lbl = new System.Windows.Forms.Label();
            this.exit_btn = new System.Windows.Forms.Button();
            this.End_btn = new System.Windows.Forms.Button();
            this.Endnotetxt = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.EndGview)).BeginInit();
            this.SuspendLayout();
            // 
            // EndGview
            // 
            this.EndGview.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.EndGview.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.EndGview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.EndGview.Location = new System.Drawing.Point(396, 63);
            this.EndGview.Name = "EndGview";
            this.EndGview.RowHeadersWidth = 51;
            this.EndGview.RowTemplate.Height = 24;
            this.EndGview.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.EndGview.Size = new System.Drawing.Size(866, 334);
            this.EndGview.TabIndex = 16;
            this.EndGview.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.EndGview_CellClick);
            // 
            // Endtxt
            // 
            this.Endtxt.AccessibleRole = System.Windows.Forms.AccessibleRole.IpAddress;
            this.Endtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Endtxt.ForeColor = System.Drawing.Color.DarkGray;
            this.Endtxt.Location = new System.Drawing.Point(199, 142);
            this.Endtxt.Name = "Endtxt";
            this.Endtxt.Size = new System.Drawing.Size(130, 27);
            this.Endtxt.TabIndex = 19;
            this.Endtxt.Text = "##########";
            this.Endtxt.Enter += new System.EventHandler(this.Endtxt_Enter);
            this.Endtxt.Leave += new System.EventHandler(this.Endtxt_Leave);
            // 
            // code_lbl
            // 
            this.code_lbl.AccessibleRole = System.Windows.Forms.AccessibleRole.IpAddress;
            this.code_lbl.AutoSize = true;
            this.code_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.code_lbl.Location = new System.Drawing.Point(37, 142);
            this.code_lbl.Name = "code_lbl";
            this.code_lbl.Size = new System.Drawing.Size(94, 25);
            this.code_lbl.TabIndex = 18;
            this.code_lbl.Text = "Claim ID";
            // 
            // End_clm_lbl
            // 
            this.End_clm_lbl.AccessibleRole = System.Windows.Forms.AccessibleRole.IpAddress;
            this.End_clm_lbl.AutoSize = true;
            this.End_clm_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.End_clm_lbl.Location = new System.Drawing.Point(64, 39);
            this.End_clm_lbl.Name = "End_clm_lbl";
            this.End_clm_lbl.Size = new System.Drawing.Size(221, 51);
            this.End_clm_lbl.TabIndex = 17;
            this.End_clm_lbl.Text = "End Claim";
            // 
            // exit_btn
            // 
            this.exit_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit_btn.Location = new System.Drawing.Point(210, 355);
            this.exit_btn.Name = "exit_btn";
            this.exit_btn.Size = new System.Drawing.Size(130, 42);
            this.exit_btn.TabIndex = 21;
            this.exit_btn.Text = "Back";
            this.exit_btn.UseVisualStyleBackColor = true;
            this.exit_btn.Click += new System.EventHandler(this.exit_btn_Click);
            // 
            // End_btn
            // 
            this.End_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.End_btn.Location = new System.Drawing.Point(25, 355);
            this.End_btn.Name = "End_btn";
            this.End_btn.Size = new System.Drawing.Size(130, 42);
            this.End_btn.TabIndex = 20;
            this.End_btn.Text = "End Claim";
            this.End_btn.UseVisualStyleBackColor = true;
            this.End_btn.Click += new System.EventHandler(this.End_btn_Click);
            // 
            // Endnotetxt
            // 
            this.Endnotetxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Endnotetxt.ForeColor = System.Drawing.Color.DarkGray;
            this.Endnotetxt.Location = new System.Drawing.Point(25, 194);
            this.Endnotetxt.Multiline = true;
            this.Endnotetxt.Name = "Endnotetxt";
            this.Endnotetxt.Size = new System.Drawing.Size(315, 137);
            this.Endnotetxt.TabIndex = 22;
            this.Endnotetxt.Text = "Please add a note here.";
            this.Endnotetxt.Enter += new System.EventHandler(this.Endnotetxt_Enter);
            this.Endnotetxt.Leave += new System.EventHandler(this.Endnotetxt_Leave);
            // 
            // End_Claim
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1285, 421);
            this.Controls.Add(this.Endnotetxt);
            this.Controls.Add(this.exit_btn);
            this.Controls.Add(this.End_btn);
            this.Controls.Add(this.Endtxt);
            this.Controls.Add(this.code_lbl);
            this.Controls.Add(this.End_clm_lbl);
            this.Controls.Add(this.EndGview);
            this.Name = "End_Claim";
            this.Text = "End";
            ((System.ComponentModel.ISupportInitialize)(this.EndGview)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView EndGview;
        private System.Windows.Forms.TextBox Endtxt;
        private System.Windows.Forms.Label code_lbl;
        private System.Windows.Forms.Label End_clm_lbl;
        private System.Windows.Forms.Button exit_btn;
        private System.Windows.Forms.Button End_btn;
        private System.Windows.Forms.TextBox Endnotetxt;
    }
}