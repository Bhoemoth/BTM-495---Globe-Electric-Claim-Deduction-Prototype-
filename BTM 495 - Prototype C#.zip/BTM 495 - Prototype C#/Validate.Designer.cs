﻿namespace btm_495
{
    partial class Validate_Claim
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Trans_clm_lbl = new System.Windows.Forms.Label();
            this.clm_code_lbl = new System.Windows.Forms.Label();
            this.trans_btn = new System.Windows.Forms.Button();
            this.ext_btn = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.validateGridView = new System.Windows.Forms.DataGridView();
            this.outputgrd = new System.Windows.Forms.DataGridView();
            this.Clearbtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.validateGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.outputgrd)).BeginInit();
            this.SuspendLayout();
            // 
            // Trans_clm_lbl
            // 
            this.Trans_clm_lbl.AutoSize = true;
            this.Trans_clm_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Trans_clm_lbl.Location = new System.Drawing.Point(97, 24);
            this.Trans_clm_lbl.Name = "Trans_clm_lbl";
            this.Trans_clm_lbl.Size = new System.Drawing.Size(315, 51);
            this.Trans_clm_lbl.TabIndex = 0;
            this.Trans_clm_lbl.Text = "Validate Claim";
            // 
            // clm_code_lbl
            // 
            this.clm_code_lbl.AutoSize = true;
            this.clm_code_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clm_code_lbl.Location = new System.Drawing.Point(83, 144);
            this.clm_code_lbl.Name = "clm_code_lbl";
            this.clm_code_lbl.Size = new System.Drawing.Size(174, 25);
            this.clm_code_lbl.TabIndex = 1;
            this.clm_code_lbl.Text = "Deduction Code:";
            // 
            // trans_btn
            // 
            this.trans_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trans_btn.Location = new System.Drawing.Point(42, 208);
            this.trans_btn.Name = "trans_btn";
            this.trans_btn.Size = new System.Drawing.Size(125, 42);
            this.trans_btn.TabIndex = 2;
            this.trans_btn.Text = "Translate";
            this.trans_btn.UseVisualStyleBackColor = true;
            this.trans_btn.Click += new System.EventHandler(this.trans_btn_Click);
            // 
            // ext_btn
            // 
            this.ext_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ext_btn.Location = new System.Drawing.Point(351, 208);
            this.ext_btn.Name = "ext_btn";
            this.ext_btn.Size = new System.Drawing.Size(125, 42);
            this.ext_btn.TabIndex = 3;
            this.ext_btn.Text = "Back";
            this.ext_btn.UseVisualStyleBackColor = true;
            this.ext_btn.Click += new System.EventHandler(this.ext_btn_Click);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.DarkGray;
            this.textBox1.Location = new System.Drawing.Point(298, 139);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(126, 27);
            this.textBox1.TabIndex = 6;
            this.textBox1.Text = "##########";
            this.textBox1.Enter += new System.EventHandler(this.textBox1_Enter);
            this.textBox1.Leave += new System.EventHandler(this.textBox1_Leave);
            // 
            // validateGridView
            // 
            this.validateGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.validateGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.validateGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.validateGridView.Location = new System.Drawing.Point(540, 40);
            this.validateGridView.Name = "validateGridView";
            this.validateGridView.RowHeadersWidth = 51;
            this.validateGridView.RowTemplate.Height = 24;
            this.validateGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.validateGridView.Size = new System.Drawing.Size(866, 347);
            this.validateGridView.TabIndex = 7;
            this.validateGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.validateGridView_CellClick);
            // 
            // outputgrd
            // 
            this.outputgrd.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.outputgrd.Location = new System.Drawing.Point(29, 275);
            this.outputgrd.Name = "outputgrd";
            this.outputgrd.RowHeadersWidth = 51;
            this.outputgrd.RowTemplate.Height = 24;
            this.outputgrd.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.outputgrd.Size = new System.Drawing.Size(461, 112);
            this.outputgrd.TabIndex = 8;
            // 
            // Clearbtn
            // 
            this.Clearbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Clearbtn.Location = new System.Drawing.Point(196, 209);
            this.Clearbtn.Name = "Clearbtn";
            this.Clearbtn.Size = new System.Drawing.Size(125, 41);
            this.Clearbtn.TabIndex = 3;
            this.Clearbtn.Text = "Clear";
            this.Clearbtn.UseVisualStyleBackColor = true;
            this.Clearbtn.Click += new System.EventHandler(this.Clearbtn_Click);
            // 
            // Validate_Claim
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1437, 400);
            this.Controls.Add(this.outputgrd);
            this.Controls.Add(this.validateGridView);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Clearbtn);
            this.Controls.Add(this.ext_btn);
            this.Controls.Add(this.trans_btn);
            this.Controls.Add(this.clm_code_lbl);
            this.Controls.Add(this.Trans_clm_lbl);
            this.Name = "Validate_Claim";
            this.Text = "Validate";
            this.Load += new System.EventHandler(this.Validate_Claim_Load);
            ((System.ComponentModel.ISupportInitialize)(this.validateGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.outputgrd)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Trans_clm_lbl;
        private System.Windows.Forms.Label clm_code_lbl;
        private System.Windows.Forms.Button trans_btn;
        private System.Windows.Forms.Button ext_btn;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView validateGridView;
        private System.Windows.Forms.DataGridView outputgrd;
        private System.Windows.Forms.Button Clearbtn;
    }
}