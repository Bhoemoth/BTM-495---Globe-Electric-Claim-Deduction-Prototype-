﻿namespace btm_495
{
    partial class Create_Claim
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.clm_lbl = new System.Windows.Forms.Label();
            this.clm_code_lbl = new System.Windows.Forms.Label();
            this.deduc_lbl = new System.Windows.Forms.Label();
            this.descrp_lbl = new System.Windows.Forms.Label();
            this.date_lbl = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.submit_btn = new System.Windows.Forms.Button();
            this.Back_btn = new System.Windows.Forms.Button();
            this.CreateGview = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.order_ID_txt = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.CreateGview)).BeginInit();
            this.SuspendLayout();
            // 
            // clm_lbl
            // 
            this.clm_lbl.AutoSize = true;
            this.clm_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clm_lbl.Location = new System.Drawing.Point(97, 25);
            this.clm_lbl.Name = "clm_lbl";
            this.clm_lbl.Size = new System.Drawing.Size(285, 51);
            this.clm_lbl.TabIndex = 0;
            this.clm_lbl.Text = "Create Claim";
            this.clm_lbl.Click += new System.EventHandler(this.label1_Click);
            // 
            // clm_code_lbl
            // 
            this.clm_code_lbl.AutoSize = true;
            this.clm_code_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clm_code_lbl.Location = new System.Drawing.Point(34, 109);
            this.clm_code_lbl.Name = "clm_code_lbl";
            this.clm_code_lbl.Size = new System.Drawing.Size(167, 25);
            this.clm_code_lbl.TabIndex = 1;
            this.clm_code_lbl.Text = "Deduction Code";
            // 
            // deduc_lbl
            // 
            this.deduc_lbl.AutoSize = true;
            this.deduc_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deduc_lbl.Location = new System.Drawing.Point(34, 155);
            this.deduc_lbl.Name = "deduc_lbl";
            this.deduc_lbl.Size = new System.Drawing.Size(147, 25);
            this.deduc_lbl.TabIndex = 2;
            this.deduc_lbl.Text = "Claim Amount";
            // 
            // descrp_lbl
            // 
            this.descrp_lbl.AutoSize = true;
            this.descrp_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.descrp_lbl.Location = new System.Drawing.Point(34, 290);
            this.descrp_lbl.Name = "descrp_lbl";
            this.descrp_lbl.Size = new System.Drawing.Size(120, 25);
            this.descrp_lbl.TabIndex = 3;
            this.descrp_lbl.Text = "Description";
            this.descrp_lbl.Click += new System.EventHandler(this.label4_Click);
            // 
            // date_lbl
            // 
            this.date_lbl.AutoSize = true;
            this.date_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date_lbl.Location = new System.Drawing.Point(34, 198);
            this.date_lbl.Name = "date_lbl";
            this.date_lbl.Size = new System.Drawing.Size(57, 25);
            this.date_lbl.TabIndex = 4;
            this.date_lbl.Text = "Date";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.DarkGray;
            this.textBox1.Location = new System.Drawing.Point(233, 109);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(204, 27);
            this.textBox1.TabIndex = 8;
            this.textBox1.Text = "##########";
            this.textBox1.Enter += new System.EventHandler(this.textBox1_Enter);
            this.textBox1.Leave += new System.EventHandler(this.textBox1_Leave);
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.ForeColor = System.Drawing.Color.DarkGray;
            this.textBox4.Location = new System.Drawing.Point(233, 196);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(204, 27);
            this.textBox4.TabIndex = 9;
            this.textBox4.Text = "YYYY-MM-DD";
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            this.textBox4.Enter += new System.EventHandler(this.textBox4_Enter);
            this.textBox4.Leave += new System.EventHandler(this.textBox4_Leave);
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.ForeColor = System.Drawing.Color.DarkGray;
            this.textBox2.Location = new System.Drawing.Point(233, 153);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(204, 27);
            this.textBox2.TabIndex = 10;
            this.textBox2.Text = "$0.00";
            this.textBox2.Enter += new System.EventHandler(this.textBox2_Enter);
            this.textBox2.Leave += new System.EventHandler(this.textBox2_Leave);
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.ForeColor = System.Drawing.Color.DarkGray;
            this.textBox3.Location = new System.Drawing.Point(177, 290);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(266, 124);
            this.textBox3.TabIndex = 11;
            this.textBox3.Text = "Please add a description here.";
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            this.textBox3.Enter += new System.EventHandler(this.textBox3_Enter);
            this.textBox3.Leave += new System.EventHandler(this.textBox3_Leave);
            // 
            // submit_btn
            // 
            this.submit_btn.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.submit_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.submit_btn.Location = new System.Drawing.Point(38, 441);
            this.submit_btn.Name = "submit_btn";
            this.submit_btn.Size = new System.Drawing.Size(130, 49);
            this.submit_btn.TabIndex = 12;
            this.submit_btn.Text = "Submit";
            this.submit_btn.UseVisualStyleBackColor = true;
            this.submit_btn.Click += new System.EventHandler(this.submit_btn_Click);
            // 
            // Back_btn
            // 
            this.Back_btn.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Back_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Back_btn.Location = new System.Drawing.Point(312, 441);
            this.Back_btn.Name = "Back_btn";
            this.Back_btn.Size = new System.Drawing.Size(131, 49);
            this.Back_btn.TabIndex = 13;
            this.Back_btn.Text = "Back";
            this.Back_btn.UseVisualStyleBackColor = true;
            this.Back_btn.Click += new System.EventHandler(this.Back_btn_Click);
            // 
            // CreateGview
            // 
            this.CreateGview.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.CreateGview.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.CreateGview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CreateGview.Location = new System.Drawing.Point(485, 72);
            this.CreateGview.Name = "CreateGview";
            this.CreateGview.RowHeadersWidth = 51;
            this.CreateGview.RowTemplate.Height = 24;
            this.CreateGview.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.CreateGview.Size = new System.Drawing.Size(861, 418);
            this.CreateGview.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(34, 241);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Order ID";
            this.label1.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // order_ID_txt
            // 
            this.order_ID_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.order_ID_txt.ForeColor = System.Drawing.Color.DarkGray;
            this.order_ID_txt.Location = new System.Drawing.Point(233, 239);
            this.order_ID_txt.Name = "order_ID_txt";
            this.order_ID_txt.Size = new System.Drawing.Size(204, 27);
            this.order_ID_txt.TabIndex = 8;
            this.order_ID_txt.Text = "##########";
            this.order_ID_txt.Enter += new System.EventHandler(this.order_ID_txt_Enter);
            this.order_ID_txt.Leave += new System.EventHandler(this.order_ID_txt_Leave);
            // 
            // Create_Claim
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1379, 516);
            this.Controls.Add(this.CreateGview);
            this.Controls.Add(this.Back_btn);
            this.Controls.Add(this.submit_btn);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.order_ID_txt);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.date_lbl);
            this.Controls.Add(this.descrp_lbl);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.deduc_lbl);
            this.Controls.Add(this.clm_code_lbl);
            this.Controls.Add(this.clm_lbl);
            this.Name = "Create_Claim";
            this.Text = "Create";
            ((System.ComponentModel.ISupportInitialize)(this.CreateGview)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label clm_lbl;
        private System.Windows.Forms.Label clm_code_lbl;
        private System.Windows.Forms.Label deduc_lbl;
        private System.Windows.Forms.Label descrp_lbl;
        private System.Windows.Forms.Label date_lbl;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button submit_btn;
        private System.Windows.Forms.Button Back_btn;
        private System.Windows.Forms.DataGridView CreateGview;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox order_ID_txt;
    }
}