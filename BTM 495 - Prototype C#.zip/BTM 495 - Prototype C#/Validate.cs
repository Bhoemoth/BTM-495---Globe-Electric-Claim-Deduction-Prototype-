﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace btm_495
{
    public partial class Validate_Claim : Form

    {
        MySqlConnection dbConn = new MySqlConnection("server = 127.0.0.1; user id = root; password= SQL123; database=btm 495");
         int Clickid = 0;
        public Validate_Claim()
        {
            InitializeComponent();
        }

        private void ext_btn_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            this.Hide();
            home.ShowDialog();
            this.Close();
        }

        private void Validate_Claim_Load(object sender, EventArgs e)
        {
            Load_data();

        }
        public void Load_data()
        {
           
            dbConn.Open();
            MySqlDataAdapter SDA = new MySqlDataAdapter("Select * from claim ", dbConn);
            DataTable DATA = new DataTable();
            SDA.Fill(DATA);
            validateGridView.DataSource = DATA;
            dbConn.Close();

            
        }
        public void Load_DeductionType()
        {
            dbConn.Open();
            MySqlDataAdapter SSS = new MySqlDataAdapter("Select Deduction_type, Deduction_Description, Order_Documents From claim_Deduction Where Deduction_code ='" + textBox1.Text + "'", dbConn);
            DataTable D = new DataTable();
            SSS.Fill(D);
            outputgrd.DataSource = D;
            dbConn.Close();

            
           
        }

        private void trans_btn_Click(object sender, EventArgs e)

        {
            if (textBox1.Text != "##########")
            {
                
                dbConn.Open();
                DataTable D = new DataTable();
                dbConn.Close();

                 if (double.Parse(validateGridView.CurrentRow.Cells[1].Value.ToString()) < 100 )
                { MessageBox.Show("As the claim is less than $100, it will be simply paid to the customer.");
                    dbConn.Open();
                    MySqlDataAdapter SDA = new MySqlDataAdapter("UPDATE Claim SET Claim_Status = 'To be Paid' WHERE Claim_Deduction_Code ='" + textBox1.Text + "'", dbConn);
                    DataTable DATA = new DataTable();
                    SDA.SelectCommand.ExecuteNonQuery();
                    dbConn.Close();
                    Load_data();
                    textBox1.Text = "##########";
                    textBox1.ForeColor = Color.DarkGray;
                 }

                else { 

                try
                    {
                        
                   

                Load_DeductionType();

                dbConn.Open();
                    MySqlDataAdapter SDA = new MySqlDataAdapter("UPDATE Claim SET Claim_Status = 'Validated' WHERE Claim_Deduction_Code ='" + textBox1.Text + "'", dbConn);
                    DataTable DATA = new DataTable();
                    SDA.SelectCommand.ExecuteNonQuery();
                    dbConn.Close();

            
                    Load_data();
                    
                    // MessageBox.Show("The claim code has been translated. Please check the table to see what documents you need to complete the validation process");
                    MessageBox.Show("The Deduction Code for claim has been translated successfully." +"\n" + "The deduction type is " + outputgrd.CurrentRow.Cells[1].Value.ToString() + ". " + "\n" + "Please find the associated " + outputgrd.CurrentRow.Cells[2].Value.ToString() + " to complete the validation process.");
                    }
                  
                    catch (Exception)
                    {
                        MessageBox.Show("Claim Deduction Code is not valid." +"\n" + "Please check the Claim Deduction Code." );
;                    }


                }
            }
            else
            {
                MessageBox.Show("Please enter a valid Claim Deduction Code");
            }

        }

        private void validateGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (validateGridView.CurrentRow.Index != -1)

                {
                    Clickid = Convert.ToInt32(validateGridView.CurrentRow.Cells[0].Value.ToString());
                    textBox1.Text = validateGridView.CurrentRow.Cells[3].Value.ToString();
                    textBox1.ForeColor = Color.Black;

                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            if (textBox1.Text == "##########")
            {
                textBox1.Text = "";

                textBox1.ForeColor = Color.Black;
            }
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = "##########";

                textBox1.ForeColor = Color.DarkGray;
            }
        }

        private void Clearbtn_Click(object sender, EventArgs e)
        {
            textBox1.Text = "##########";
            textBox1.ForeColor = Color.DarkGray;
            dbConn.Open();
            MySqlDataAdapter SSS = new MySqlDataAdapter("Select Deduction_type, Deduction_Description, Order_Documents From claim_Deduction Where Deduction_code ='" + textBox1.Text + "'", dbConn);
            DataTable D = new DataTable();
            SSS.Fill(D);
            outputgrd.DataSource = D;
            dbConn.Close();
            D.Rows.Clear();
            outputgrd.Refresh();


        }


      
    }
}

