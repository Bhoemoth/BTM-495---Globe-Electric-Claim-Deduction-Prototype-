﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace btm_495
{
    public partial class Create_Claim : Form
    {
        MySqlConnection dbConn = new MySqlConnection("server = 127.0.0.1; user id = root; password= SQL123; database=btm 495");
        public Create_Claim()
        {
            InitializeComponent();
            load_data();
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            this.Hide();
            home.ShowDialog();
            this.Close();


        }

        private void submit_btn_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "##########" && textBox2.Text != "$0.00" && textBox3.Text != "Please add a description here." && textBox4.Text != "YYYY-MM-DD")
            {
                MySqlCommand cmd = new MySqlCommand("Insert into claim(Claim_Amount,Claim_Description,Claim_Deduction_Code,Claim_Date, Order_ID)Values('" + textBox2.Text + "','" + textBox3.Text + "','" + textBox1.Text + "','" + textBox4.Text + "','" + order_ID_txt.Text + "')", dbConn);
            dbConn.Open();
            try
            { cmd.ExecuteNonQuery();
                MessageBox.Show("The claim has been submitted successfully.");
                
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                order_ID_txt.Clear();
                                                 

            }
                        
            catch (Exception ex)
            {
                MessageBox.Show("Error!" + "\n" + "The data entered is invalid. " + "Please check your data inputs," + "\n\n" + ex.Message ) ;
                    
            }
            dbConn.Close();
             load_data();
            }
            else
            {

                MessageBox.Show("Error!" + "\n" + "Either the data entered is invalid or required data fields have been left empty.");

            }

        }

        public void load_data()
        {
            dbConn.Open();
            MySqlDataAdapter SDA = new MySqlDataAdapter("Select Claim_ID,Concat('$',Format(Claim_Amount, 'C3')) As Claim_Amount, Claim_Status, Claim_Deduction_Code, Claim_Date, Order_ID, Claim_Description, Claim_Notes from claim ", dbConn);
            DataTable DATA = new DataTable();
            SDA.Fill(DATA);
            CreateGview.DataSource = DATA;
            dbConn.Close();

            dbConn.Close();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            if (textBox1.Text == "##########")
            {
                textBox1.Text = "";

                textBox1.ForeColor = Color.Black;
            }
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = "##########";

                textBox1.ForeColor = Color.DarkGray;
            }
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            if (textBox2.Text == "$0.00")
            {
                textBox2.Text = "";

                textBox2.ForeColor = Color.Black;
            }
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                textBox2.Text = "$0.00";

                textBox2.ForeColor = Color.DarkGray;
            }
        }

        private void textBox3_Enter(object sender, EventArgs e)
        {
            if (textBox3.Text == "Please add a description here.")
            {
                textBox3.Text = "";

                textBox3.ForeColor = Color.Black;

        }      
    }

        private void textBox3_Leave(object sender, EventArgs e)
        {
            if (textBox3.Text == "")
            {
                textBox3.Text = "Please add a description here.";
                textBox3.ForeColor = Color.DarkGray;
            }


        }

        private void textBox4_Enter(object sender, EventArgs e)
        {
            if (textBox4.Text == "YYYY-MM-DD")
            {
                textBox4.Text = "";

                textBox4.ForeColor = Color.Black;
            }
        }

        private void textBox4_Leave(object sender, EventArgs e)
        {
            
            if (textBox4.Text == "")
            {
                textBox4.Text = "YYYY-MM-DD";

                textBox4.ForeColor = Color.DarkGray;
            }
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void order_ID_txt_Enter(object sender, EventArgs e)
        {
            if (order_ID_txt.Text == "##########")
            {
                order_ID_txt.Text = "";

                order_ID_txt.ForeColor = Color.Black;
            }
        }

        private void order_ID_txt_Leave(object sender, EventArgs e)
        {
            if (order_ID_txt.Text == "")
            {
                order_ID_txt.Text = "##########";

                order_ID_txt.ForeColor = Color.DarkGray;
            }
        }
    }

}
